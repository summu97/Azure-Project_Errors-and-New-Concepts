#!/bin/bash
set -euo pipefail

SERVICE_NAME=$1
IMAGE_TAG=$2

trivy image --format json \
    --output "${SERVICE_NAME}_${IMAGE_TAG}_audit_report.json" \
    codaregistry.azurecr.io/${SERVICE_NAME}:${IMAGE_TAG}
