#!/bin/bash
set -euo pipefail

ACCT=$1
KV=$2
SECRET_NAME=$3
CONTAINER=$4
PREFIX=$5
IMAGE_TAG=$6
SERVICE_NAME=$7
LOCAL_JSON=$8
LOCAL_XLS=$9

BLOB_JSON="${PREFIX}/${IMAGE_TAG}/${SERVICE_NAME}_${IMAGE_TAG}_audit_report.json"
BLOB_XLS="${PREFIX}/${IMAGE_TAG}/${SERVICE_NAME}_${IMAGE_TAG}_audit_report.xlsx"

echo "Retrieving storage account key from Key Vault: $KV"
KEY=$(az keyvault secret show --vault-name "$KV" --name "$SECRET_NAME" --query value -o tsv)
if [[ -z "$KEY" ]]; then
    echo "ERROR: storage key is empty"
    exit 1
fi

az storage container create --name "$CONTAINER" --account-name "$ACCT" --account-key "$KEY" --public-access off >/dev/null

echo "Uploading $LOCAL_JSON -> $BLOB_JSON"
az storage blob upload --container-name "$CONTAINER" --file "$LOCAL_JSON" --name "$BLOB_JSON" --account-name "$ACCT" --account-key "$KEY" --overwrite true

echo "Uploading $LOCAL_XLS -> $BLOB_XLS"
az storage blob upload --container-name "$CONTAINER" --file "$LOCAL_XLS" --name "$BLOB_XLS" --account-name "$ACCT" --account-key "$KEY" --overwrite true

echo "Upload complete."
