#!/usr/bin/env python3
import pandas as pd, json, sys

CRITICAL_THRESHOLD = 0.5
HIGH_THRESHOLD = 5.0

input_file = sys.argv[1]
output_file = sys.argv[2]
status_file = sys.argv[3]

with open(input_file) as f:
    data = json.load(f)

rows = []
severity_counts = {"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0,"UNKNOWN":0}
total = 0

for r in data.get("Results", []):
    for v in r.get("Vulnerabilities", []):
        sev = v.get("Severity","UNKNOWN").upper()
        severity_counts[sev] = severity_counts.get(sev,0) + 1
        total += 1
        rows.append({
            "Target": r.get("Target"),
            "VulnerabilityID": v.get("VulnerabilityID"),
            "PkgName": v.get("PkgName"),
            "InstalledVersion": v.get("InstalledVersion"),
            "FixedVersion": v.get("FixedVersion"),
            "Severity": sev,
            "Title": v.get("Title")
        })

df = pd.DataFrame(rows)
df.to_excel(output_file, index=False)

status = "PASS"
if total > 0:
    critical_pct = (severity_counts.get("CRITICAL",0)/total)*100
    high_pct = (severity_counts.get("HIGH",0)/total)*100
    if critical_pct > CRITICAL_THRESHOLD or high_pct > HIGH_THRESHOLD:
        status = "FAIL"

with open(status_file, "w") as sf:
    sf.write(status)
