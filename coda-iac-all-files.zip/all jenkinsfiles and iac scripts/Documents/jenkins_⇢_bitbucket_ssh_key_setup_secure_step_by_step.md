# Jenkins  Bitbucket SSH Key Setup (secure, step-by-step)
---------------------------------------------------------------------------------------------------------------------------------------------------

## Purpose
Use SSH keys to allow Jenkins to clone/push to Bitbucket securely. Keep the private key encrypted inside Jenkins Credentials (no long-lived private key files on the Jenkins node filesystem).

## Prerequisites
- Admin access to Bitbucket account (or repo admin access) to add keys.
- Admin or sudo access to the Jenkins master/agent to run a few commands as the `jenkins` service user for known_hosts.
- Jenkins with the Git plugin installed.

---------------------------------------------------------------------------------------------------------------------------------------------------

## 1) Generate the SSH key pair (on your *local* machine)
> Do this locally (developer/admin machine), not on Jenkins master.

```bash
ssh-keygen -t ed25519 -C "jenkinsadmin@CODA-PROD-Jenkins" -f ./jenkins-bitbucket
# When prompted for passphrase, press Enter twice (leave empty) for non-interactive CI use.
# Files created: ./jenkins-bitbucket (private), ./jenkins-bitbucket.pub (public)
```

**Notes:**
- `ed25519` is recommended (modern, fast, secure). Use RSA (4096) only for old compat constraints.
- Keep the private key secure; do not upload it to source control.

---------------------------------------------------------------------------------------------------------------------------------------------------

## 2) Add public key to Bitbucket
Choose one of the options below depending on access scope required.

### Repository-level (deploy key, read-only)
1. Go to the repository → **Settings → Access keys**.
2. Click **Add key**.
3. Paste the contents of `jenkins-bitbucket.pub`.
4. Name it like: `jenkins-ci-cacheservice`.

### Account-level (personal key, can allow write if desired)
1. Go to **Personal settings → SSH keys**.
2. Click **Add key**, paste `jenkins-bitbucket.pub`, save.

**Recommendation:** Use repo-level access keys where possible for least privilege.

---------------------------------------------------------------------------------------------------------------------------------------------------

## 3) Add private key to Jenkins Credentials (secure storage)
1. In Jenkins UI → **Manage Jenkins → Credentials** → choose the domain (usually `(global)`).
2. Click **Add Credentials**.
   - **Kind:** SSH Username with private key
   - **Username:** `git`
   - **Private Key:** *Enter directly* → paste the contents of `jenkins-bitbucket` (private key file)
   - **ID:** `bitbucket-ssh` (or a meaningful ID)
   - **Description:** `Bitbucket deploy key for Jenkins CI`
3. Save.

**Why:** Jenkins encrypts credentials and injects them at runtime. No permanent private key file is required on the build agents.

---------------------------------------------------------------------------------------------------------------------------------------------------

## 4) Configure Git Host Key Verification (known_hosts) for the `jenkins` runtime user
Jenkins will refuse SSH connections if it cannot verify the host key. Do this on the Jenkins master (or on the agent that performs the checkout) as the `jenkins` user.

**Commands (run as root or a sudo user):**

```bash
# switch to jenkins user and create the .ssh dir
sudo su - jenkins -s /bin/bash -c 'mkdir -p ~/.ssh && chmod 700 ~/.ssh'

# append Bitbucket host keys (run as jenkins)
sudo su - jenkins -s /bin/bash -c 'ssh-keyscan bitbucket.org >> ~/.ssh/known_hosts'

# set permissions
sudo su - jenkins -s /bin/bash -c 'chmod 644 ~/.ssh/known_hosts'
```

**Verify:**
```bash
sudo su - jenkins -s /bin/bash -c 'grep bitbucket.org ~/.ssh/known_hosts'
```

This ensures the Git client run by Jenkins trusts `bitbucket.org` and avoids "Host key verification failed" errors.

---------------------------------------------------------------------------------------------------------------------------------------------------

## 5) Jenkinsfile examples — using the stored SSH credential
### Simple `git` step
```groovy
pipeline {
  agent any
  stages {
    stage('Checkout') {
      steps {
        git branch: 'main',
            credentialsId: 'bitbucket-ssh',
            url: 'git@bitbucket.org:yourteam/your-repo.git'
      }
    }
  }
}
```

### Using `checkout` with multiple repos (example matching your pipeline)
```groovy
stage('Checkout') {
  steps {
    cleanWs()
    script {
      git branch: currentBranch,
          credentialsId: 'bitbucket-ssh',
          url: "git@bitbucket.org:asaiprdf/${params.SERVICE_NAME}.git"

      dir("${WORKSPACE}/pipeline-scripts") {
        git branch: 'master',
            credentialsId: 'bitbucket-ssh',
            url: 'git@bitbucket.org:asaiprdf/aftra-iac-scripts.git'
      }
    }
  }
}
```

---------------------------------------------------------------------------------------------------------------------------------------------------

## 6) (Optional) Use `sshagent` for manual SSH steps inside pipeline
If you need to run custom `ssh` or `git` commands inside a build step, you can wrap them with `sshagent`:

```groovy
sshagent(credentials: ['bitbucket-ssh']) {
  sh 'ssh -T git@bitbucket.org || true'
  sh 'git ls-remote git@bitbucket.org:asaiprdf/cacheservice.git'
}
```

`sshagent` temporarily provides the private key to the build environment.

---------------------------------------------------------------------------------------------------------------------------------------------------

## 7) Test checklist
1. `jenkins-bitbucket.pub` is added to Bitbucket (repo or account as required).
2. Jenkins global credential `bitbucket-ssh` exists and contains the private key.
3. `/var/lib/jenkins/.ssh/known_hosts` (or `~jenkins/.ssh/known_hosts`) contains Bitbucket host fingerprints.
4. Your pipeline's `credentialsId` matches the credential ID in Jenkins.
5. Run a simple job with a `git` checkout; logs should show successful authentication (no "permission denied").

---

## 8) Troubleshooting
- **`Permission denied (publickey)`** → Private key missing in Jenkins Credentials or public key not added to Bitbucket.
- **`No ED25519 host key known`** → known_hosts not populated for Jenkins runtime user.
- **`Host key verification failed`** → ensure file permissions are `700` for `.ssh` and `644` for `known_hosts` and that Jenkins user owns them.
- If using ephemeral agents (e.g., Kubernetes), ensure you add the host key in the agent image or use Jenkins Host Key Verification plugin strategies (e.g., Accept First Connection or provide a known_hosts global file).

---------------------------------------------------------------------------------------------------------------------------------------------------

## 9) Security & rotation best practices
- Store the private key only in Jenkins Credentials (avoid disk copies on nodes).
- Use **repo-level deploy keys** for least privilege whenever possible (read-only if push is not needed).
- Rotate keys periodically and whenever an admin leaves.
- Use an audit trail: record credential ID usage and job access.
- If you must allow pushes from Jenkins, create a dedicated Key with write permission and restrict it to specific repos.

---------------------------------------------------------------------------------------------------------------------------------------------------

## 10) Quick rollback (revoke access)
- Remove the public key from Bitbucket (repo or account).
- Delete the corresponding Jenkins credential.

---------------------------------------------------------------------------------------------------------------------------------------------------

## 11) Appendix: Useful commands (copy-paste)
```bash
# generate key locally
ssh-keygen -t ed25519 -C "jenkinsadmin@CODA-PROD-Jenkins" -f ./jenkins-bitbucket

# add Bitbucket host keys for jenkins user
sudo su - jenkins -s /bin/bash -c 'mkdir -p ~/.ssh && chmod 700 ~/.ssh'
sudo su - jenkins -s /bin/bash -c 'ssh-keyscan bitbucket.org >> ~/.ssh/known_hosts'
sudo su - jenkins -s /bin/bash -c 'chmod 644 ~/.ssh/known_hosts'

# verify from jenkins user
sudo su - jenkins -s /bin/bash -c 'ssh -T git@bitbucket.org'

# verify that the public key is present in Bitbucket (manual step in web UI)
```

---------------------------------------------------------------------------------------------------------------------------------------------------

