Alright 😄 — I’ll give you the **final working solution** for fetching Redis password from Azure Key Vault using environment files, without losing any configs we discussed.

I’ll also **document everything we’ve done so far** so it’s clean and reproducible.

---

## **1. Final Redis systemd service file**

Location:

```
/usr/lib/systemd/system/redis.service
```

Content:

```ini
[Unit]
Description=Redis persistent key-value database
After=network.target network-online.target
Wants=network-online.target

[Service]
EnvironmentFile=/etc/redis/redis.env
ExecStart=/usr/bin/redis-server /etc/redis/redis.conf --requirepass $REDIS_PASSWORD --supervised systemd

Type=notify
User=redis
Group=redis
RuntimeDirectory=redis
RuntimeDirectoryMode=0755

# Self-healing settings
Restart=always
RestartSec=5

LimitNOFILE=100000

[Install]
WantedBy=multi-user.target
```

✅ This **removes** the wrapper script problems and keeps it clean.

---

## **2. Environment file for Redis password**

Location:

```
/etc/redis/redis.env
```

Content:

```
REDIS_PASSWORD=your_secret_password_here
```

Permissions:

```bash
sudo chown redis:redis /etc/redis/redis.env
sudo chmod 600 /etc/redis/redis.env
```

This file **must exist before Redis starts**, otherwise it will fail.

---

## **3. Script to fetch password from Azure Key Vault**

Location:

```
/usr/local/bin/update-redis-password.sh
```

Content:

```bash
#!/bin/bash
# Fetch Redis password from Azure Key Vault
SECRET=$(az keyvault secret show --vault-name codadev --name redis-password --query value -o tsv)

if [ -z "$SECRET" ]; then
    echo "Failed to fetch Redis password from Key Vault" >&2
    exit 1
fi

echo "REDIS_PASSWORD=$SECRET" > /etc/redis/redis.env
chown redis:redis /etc/redis/redis.env
chmod 600 /etc/redis/redis.env
```

Permissions:

```bash
sudo chmod +x /usr/local/bin/update-redis-password.sh
```

---

## **4. Run this script automatically**

We have two options:

### **Option A: Cron job** (simplest)

Edit crontab:

```bash
sudo crontab -e
```

Add:

```
0 0 * * * /usr/local/bin/update-redis-password.sh
```

(This will run every day at midnight.)

---

### **Option B: systemd timer** (more advanced)

Create:

```
/etc/systemd/system/update-redis-password.service
```

Content:

```ini
[Unit]
Description=Update Redis password from Azure Key Vault

[Service]
Type=oneshot
ExecStart=/usr/local/bin/update-redis-password.sh
```

Create:

```
/etc/systemd/system/update-redis-password.timer
```

Content:

```ini
[Unit]
Description=Run update-redis-password.service daily

[Timer]
OnCalendar=daily
Persistent=true

[Install]
WantedBy=timers.target
```

Commands:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now update-redis-password.timer
```

---

## **5. Reload systemd and restart Redis**

```bash
sudo systemctl daemon-reload
sudo systemctl enable redis
sudo systemctl restart redis
```

---

## **6. Documentation of what we did**

### **Purpose**

We wanted to **remove hardcoded Redis password** and **fetch it dynamically from Azure Key Vault**, without breaking systemd startup or causing permission issues.

### **Changes Made**

1. **Created environment file** `/etc/redis/redis.env` to store Redis password.
2. **Removed wrapper script from systemd** to avoid execution issues.
3. **Updated `redis.service`** to use `EnvironmentFile=/etc/redis/redis.env`.
4. **Created password-fetch script** `/usr/local/bin/update-redis-password.sh` to pull secret from Azure Key Vault.
5. **Added cron job or systemd timer** to update `/etc/redis/redis.env` automatically.

### **File locations and permissions**

| File                                                           | Purpose                          | Owner         | Permissions |
| -------------------------------------------------------------- | -------------------------------- | ------------- | ----------- |
| `/etc/redis/redis.env`                                         | Stores Redis password            | `redis:redis` | `600`       |
| `/usr/local/bin/update-redis-password.sh`                      | Fetches password from Key Vault  | `root:root`   | `755`       |
| `/usr/lib/systemd/system/redis.service`                        | Redis systemd service definition | `root:root`   | `644`       |
| `/etc/systemd/system/update-redis-password.service` (optional) | Timer service definition         | `root:root`   | `644`       |
| `/etc/systemd/system/update-redis-password.timer` (optional)   | Timer for password refresh       | `root:root`   | `644`       |

---

### **Advantages**

* Secure: no hardcoded passwords in config files.
* Maintains systemd best practices.
* Avoids parsing errors seen earlier.
* Automatically updates password daily without downtime.

---

