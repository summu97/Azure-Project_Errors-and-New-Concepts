RESOURCE_GROUP="coda_rg"
DAYS_OLD_THRESHOLD=1  # Adjust this value as needed (e.g., 7 for one week)

# Calculate the date threshold
DATE_THRESHOLD=$(date --date="$DAYS_OLD_THRESHOLD days ago" +%Y-%m-%dT%H:%M:%SZ)

# Retrieve the list of snapshots in the specified resource group
SNAPSHOTS=$(az snapshot list --resource-group "$RESOURCE_GROUP" --query "[?timeCreated<'$DATE_THRESHOLD'].name" -o tsv)
echo $SNAPSHOTS

# Loop through each snapshot and delete it
for SNAPSHOT_NAME in $SNAPSHOTS; do
    # Delete the snapshot
    az snapshot delete --resource-group "$RESOURCE_GROUP" --name "$SNAPSHOT_NAME"
    echo "Deleted snapshot: $SNAPSHOT_NAME"
done