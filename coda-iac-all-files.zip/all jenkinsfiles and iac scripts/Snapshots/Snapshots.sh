#!/bin/bash
# Set the resource group
RESOURCE_GROUP="coda_rg"

# Function to take a snapshot of a disk
take_snapshot() {
    local disk_id=$1
    local disk_name=$2
    local disk_name=$(echo "$disk_name"| cut -c1-24)

    # Generate a unique name for the snapshot
    local snapshot_name="${disk_name}-snapshot-$(date +%Y%m%d%H%M%S)"
	echo "Snapshot Name is:$snapshot_name"

    # Create the snapshot of the disk
    az snapshot create --resource-group "$RESOURCE_GROUP" --source "$disk_id" \
        --name "$snapshot_name" --query "name" -o tsv
    
    echo "Snapshot $snapshot_name is created for DISK NAME: $disk_name."
}

# Function to take snapshots of both the OS and data disks of a VM
take_vm_disk_snapshots() {
    local vm_name=$1

    # Retrieve the VM's OS disk ID
    os_disk_id=$(az vm show --resource-group "$RESOURCE_GROUP" --name "$vm_name" \
        --query "storageProfile.osDisk.managedDisk.id" -o tsv)
    
    # Retrieve the VM's data disk IDs
    data_disks=$(az vm show --resource-group "$RESOURCE_GROUP" --name "$vm_name" \
        --query "storageProfile.dataDisks[].managedDisk.id" -o tsv)

    # If the VM has an OS disk, take a snapshot of it
    if [[ -n "$os_disk_id" ]]; then
        os_disk_name=$(basename "$os_disk_id")
        take_snapshot "$os_disk_id" "$os_disk_name"
    else
        echo "No OS disk found for VM: $vm_name"
    fi

    # Loop through each data disk and take a snapshot
    for data_disk_id in $data_disks; do
        data_disk_name=$(basename "$data_disk_id")
        take_snapshot "$data_disk_id" "$data_disk_name"
    done
}

# Main script execution
# Retrieve a list of all VMs in the resource group
vm_names=$(az vm list --resource-group "$RESOURCE_GROUP" --query "[].name" -o tsv)

# Loop through each VM name and take snapshots of its OS disk and data disks
for vm_name in $vm_names; do
    echo "Processing VM: $vm_name"
    take_vm_disk_snapshots "$vm_name"
done