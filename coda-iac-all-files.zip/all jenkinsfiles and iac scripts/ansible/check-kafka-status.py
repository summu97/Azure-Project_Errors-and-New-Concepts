#!/home/jenkinsadmin/venv/bin/python3

import os
import time
import uuid
import paramiko
import tempfile
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient
from kubernetes import client, config
from kubernetes.stream import stream

# -----------------------------
# Servers to stop/start/check
# -----------------------------
servers = {
    "rheldevqa": {"host": "rheldevqa", "user": "adminuser"},
    "rheluat": {"host": "redhatserveruat", "user": "adminuser"},
}

# -----------------------------
# Kafka cluster namespaces
# -----------------------------
env_map = {
    "DevFundCluster": {
        "context": "DevFundCluster",
        "namespaces": {
            "codadev": {"host": "10.0.2.33", "port": 9092, "server_name": "rheldevqa"},
            "codaqa": {"host": "10.0.2.33", "port": 9092, "server_name": "rheldevqa"},
        },
    },
    "CODAUATCluster": {
        "context": "CODAUATCluster",
        "namespaces": {
            "codauat": {"host": "10.0.2.37", "port": 9092, "server_name": "rheluat"},
        },
    },
}

# -----------------------------
# Azure Key Vault
# -----------------------------
KEYVAULT_NAME = "codadev"
kv_uri = f"https://{KEYVAULT_NAME}.vault.azure.net"
credential = ManagedIdentityCredential()
kv_client = SecretClient(vault_url=kv_uri, credential=credential)

# Secrets
private_key_value = kv_client.get_secret("kafka-status-key").value
smtp_user = kv_client.get_secret("CODADEVSMPTUSER").value
smtp_password = kv_client.get_secret("CODADEVSMTPPASSWORD").value

smtp_server = "smtp.cloudmail.email"
smtp_port = 587
from_addr = "noreply@afmsagaftrafund.org"
to_addrs = [
    "vbboya@afmsagaftrafund.org",
    "dkgiddaluri@afmsagaftrafund.org",
    "nganesh@afmsagaftrafund.org"
]

# -----------------------------
# Stop + Start with retries until running
# -----------------------------
def ensure_service_running(server, svc, port, private_key, max_attempts=5, wait=10):
    tmpkey_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, mode="w") as tmpkey:
            tmpkey.write(private_key)
            tmpkey_path = tmpkey.name
        os.chmod(tmpkey_path, 0o600)

        ssh_key = paramiko.RSAKey.from_private_key_file(tmpkey_path)
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(hostname=server["host"], username=server["user"], pkey=ssh_key, timeout=15)

        # Retry loop
        for attempt in range(1, max_attempts + 1):
            ssh.exec_command(f"sudo systemctl stop {svc}")
            time.sleep(5)
            ssh.exec_command(f"sudo systemctl start {svc}")

            # If Kafka, wait 10s for Zookeeper to stabilize first																 
            if svc == "kafka":
                print(f"[{server['host']}] Waiting 20s for Zookeeper to stabilize before starting Kafka...")
                time.sleep(20)
            else:
                time.sleep(wait)

            # Check service status
            stdin, stdout, stderr = ssh.exec_command(f"sudo systemctl is-active {svc}")
            status = stdout.read().decode().strip()
            stdin, stdout, stderr = ssh.exec_command(f"pgrep -f {svc}")
            pid_check = stdout.read().decode().strip()
            stdin, stdout, stderr = ssh.exec_command(f"sudo netstat -tulnp | grep {port}")
            port_check = stdout.read().decode().strip()

            if status == "active" and pid_check and port_check:
                ssh.close()
                return "running "
            else:
                print(f"[{server['host']}] {svc} attempt {attempt} failed, retrying...")
                time.sleep(wait)

        # Final escalation						  
        print(f"[{server['host']}] ⚠️ {svc} not running, attempting daemon-reexec")
        ssh.exec_command("sudo systemctl daemon-reexec")
        time.sleep(5)
        ssh.exec_command(f"sudo systemctl start {svc}")
        time.sleep(wait)

        stdin, stdout, stderr = ssh.exec_command(f"sudo systemctl is-active {svc}")
        status = stdout.read().decode().strip()
        stdin, stdout, stderr = ssh.exec_command(f"pgrep -f {svc}")
        pid_check = stdout.read().decode().strip()
        stdin, stdout, stderr = ssh.exec_command(f"sudo netstat -tulnp | grep {port}")
        port_check = stdout.read().decode().strip()

        ssh.close()
        return "running ✅" if status == "active" and pid_check and port_check else "FAILED "

    except Exception as e:
        return f" Failed - {e}"
    finally:
        if tmpkey_path and os.path.exists(tmpkey_path):
            os.remove(tmpkey_path)

# -----------------------------
# Kafka Connectivity Check
# -----------------------------
def check_kafka_from_pod(namespace, kafka_host, kafka_port, server_name, k8s_client):
    pod_name = f"debug-kafka-{uuid.uuid4().hex[:6]}"
    pod_manifest = client.V1Pod(
        metadata=client.V1ObjectMeta(name=pod_name),
        spec=client.V1PodSpec(
            containers=[client.V1Container(
                name="debug",
                image="busybox:latest",
                command=["sleep", "3600"]
            )],
            restart_policy="Never",
        ),
    )

    try:
        k8s_client.create_namespaced_pod(namespace=namespace, body=pod_manifest)
        print(f"🚀 Created debug pod {pod_name} in {namespace} for testing {kafka_host}:{kafka_port}")
    except Exception as e:
        return f" {namespace}: Failed to create debug pod - {e}"

    try:
        # Wait for pod to be Running
        for _ in range(30):
            pod_status = k8s_client.read_namespaced_pod_status(pod_name, namespace)
            if pod_status.status.phase == "Running":
                break
            time.sleep(2)
        else:
            return f" {namespace}: Debug pod {pod_name} did not start"

        # Use netcat (nc) to test connectivity
        exec_command = ["sh", "-c", f"nc -zv -w5 {kafka_host} {kafka_port}"]
        try:
            output = stream(
                k8s_client.connect_get_namespaced_pod_exec,
                pod_name,
                namespace,
                command=exec_command,
                stderr=True,
                stdin=False,
                stdout=True,
                tty=False
            )
            print(f"[{namespace}] nc output: {output.strip()}")

            # FIX: interpret 'open' as success
            if "open" in output.lower() or "succeeded" in output.lower():
                result = f"{namespace}: Connected to Kafka on {server_name}:{kafka_port}"
            else:
                result = f"{namespace}: Kafka connection failed on {server_name}:{kafka_port} - {output.strip()}"
        except Exception as e:
            result = f"{namespace}: Failed to exec connectivity test - {e}"

    finally:
        try:
            k8s_client.delete_namespaced_pod(pod_name, namespace)
            print(f"🧹 Deleted debug pod {pod_name} in {namespace} after testing {kafka_host}:{kafka_port}")
        except Exception as e:
            print(f"⚠️ Failed to delete pod {pod_name} in {namespace}: {e}")

    return result


# -----------------------------
# Run All Checks
# -----------------------------
service_report = {}
for name, srv in servers.items():
    # Start Zookeeper first						   
    zookeeper_status = ensure_service_running(srv, "zookeeper", 2181, private_key_value)
    # Start Kafka after Zookeeper with guaranteed 10s wait														  
    kafka_status = ensure_service_running(srv, "kafka", 9092, private_key_value)
    service_report[name] = {"zookeeper": zookeeper_status, "kafka": kafka_status}

connectivity_results = []
for cluster_name, cluster_info in env_map.items():
    config.load_kube_config(context=cluster_info["context"])
    k8s_client = client.CoreV1Api()
    for ns, kafka in cluster_info["namespaces"].items():
        connectivity_results.append(
            check_kafka_from_pod(ns, kafka["host"], kafka["port"], kafka["server_name"], k8s_client)
        )

# -----------------------------
# Build Email
# -----------------------------
body = "<h3>Kafka Daily Stop+Start & Connectivity Report</h3>"

# Service status				
body += "<h4>Service Status after Stop+Start:</h4><ul>"
for srv, res in service_report.items():
    body += f"<li>{srv}: Zookeeper: {res['zookeeper']}, Kafka: {res['kafka']}</li>"
body += "</ul>"

# Connectivity			  
body += "<h4>Connectivity Tests:</h4><ul>"
for r in connectivity_results:
    body += f"<li>{r}</li>"
body += "</ul>"

msg = MIMEMultipart()
msg["From"] = from_addr
msg["To"] = ", ".join(to_addrs)
msg["Subject"] = "Kafka Daily Stop+Start & Connectivity Report"
msg.attach(MIMEText(body, "html"))

try:
    server = smtplib.SMTP(smtp_server, smtp_port)
    server.starttls()
    server.login(smtp_user, smtp_password)
    server.sendmail(from_addr, to_addrs, msg.as_string())
    server.quit()
    print("Email sent successfully")
except Exception as e:
    print(f"Failed to send email: {e}")
