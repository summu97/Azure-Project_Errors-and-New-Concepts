import requests

url = "https://devfileingestion.afmsagaftrafund.org/fileingestion/processRank"
response = requests.get(url, timeout=10)  # no verify=False needed since cert trust fixed
response.raise_for_status()
print(response.json())
